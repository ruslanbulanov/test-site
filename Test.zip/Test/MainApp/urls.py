from django.conf.urls import url, include
from django.urls import path, reverse_lazy
from MainApp.views import *
from django.contrib.auth.views import LogoutView


urlpatterns = [
    path('', base_view, name='base'),
    path(r'category/{?P<category_slug>[-\w]+}/', category_view, name='category_detail'),
    path(r'cloth/{?P<cloth_slug>[-\w]+}/', cloth_view, name='cloth_detail'),
    path(r'add_to_cart/', add_to_cart_view, name='add_to_cart'),
    path(r'remove_from_cart/', remove_from_cart_view, name='remove_from_cart'),
    path(r'change_item_qty/', change_item_qty, name='change_item_qty'),
    path(r'checkout/', checkout_view, name='checkout'),
    path(r'order/', order_create_view, name='create_order'),
    path(r'make_order/', make_order_view, name='make_order'),
    path(r'account/', account_view, name='account'),
    path(r'registration/', registration_view, name='registration'),
    path(r'login', login_view, name='login'),
    path(r'logout/', LogoutView.as_view(next_page=reverse_lazy('base')), name='logout'),
    path(r'cart/', cart_view, name='cart')
]